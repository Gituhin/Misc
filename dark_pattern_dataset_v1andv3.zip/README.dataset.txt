# dark pattern _visual detection > 2023-02-07 1:34pm
https://universe.roboflow.com/syd-help/dark-pattern-_visual-detection

Provided by a Roboflow user
License: CC BY 4.0

